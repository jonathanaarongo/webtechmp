<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="icon" sizes="76x76" href="../assets/img/logo.png">
    <link rel="icon" type="image/png" href="images/icons/pancipane.jpg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Pancipane System</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
</head>

<body class="">
    <div class="wrapper ">
        <div class="sidebar" data-color="black">
            <div class="logo">
                <a href="" class="simple-text logo-normal">
                    <img src="images/icons/pancipane.jpg" />
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">

                    <li class="active">
                        <a href="clientDashboard.php">
                            <i style="color:black" class="now-ui-icons education_atom"></i>
                            <p style="color:black">Dashboard</p>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>Profile</p>
                        </a>
                    </li>
                    <li>
                        <a href="gallery.php">
                            <i class="now-ui-icons shopping_cart-simple"></i>
                            <p>Photo Gallery</p>
                        </a>
                    </li>

                </ul>
                <iframe scrolling="no" frameborder="no" clocktype="html5" style="overflow:hidden;border:0;margin:0;padding:0;width:200px;height:100px;margin-left:25px;margin-bottom:30px;position:fixed;bottom:0;" src="https://www.clocklink.com/html5embed.php?clock=003&timezone=GMT0800&color=orange&size=200&Title=&Message=&Target=&From=2018,1,1,0,0,0&Color=orange&DayName1=Monday&OpenHr1=7&OpenMin1=00&OpenPeriod1=am&CloseHr1=5&CloseMin1=00&ClosePeriod1=pm&ClosedAllDay1=0&OpenByAppt1=0&DayName2=Tuesday&OpenHr2=7&OpenMin2=00&OpenPeriod2=am&CloseHr2=5&CloseMin2=00&ClosePeriod2=pm&ClosedAllDay2=0&OpenByAppt2=0&DayName3=Wednesday&OpenHr3=7&OpenMin3=00&OpenPeriod3=am&CloseHr3=5&CloseMin3=00&ClosePeriod3=pm&ClosedAllDay3=0&OpenByAppt3=0&DayName4=Thursday&OpenHr4=7&OpenMin4=00&OpenPeriod4=am&CloseHr4=5&CloseMin4=00&ClosePeriod4=pm&ClosedAllDay4=0&OpenByAppt4=0&DayName5=Friday&OpenHr5=7&OpenMin5=00&OpenPeriod5=am&CloseHr5=5&CloseMin5=00&ClosePeriod5=pm&ClosedAllDay5=0&OpenByAppt5=0&DayName6=Saturday&OpenHr6=7&OpenMin6=00&OpenPeriod6=am&CloseHr6=5&CloseMin6=00&ClosePeriod6=pm&ClosedAllDay6=0&OpenByAppt6=0&DayName0=Sunday&OpenHr0=7&OpenMin0=00&OpenPeriod0=am&CloseHr0=5&CloseMin0=00&ClosePeriod0=pm&ClosedAllDay0=0&OpenByAppt0=0"></iframe>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute bg-primary fixed-top">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="navbar-brand" href="">
                            <font color="#141E30">Dashboard</font>
                        </a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <span class="badge badge-primary" style="background-color: black">Welcome, <?php echo("{$_SESSION['username']}");?>!</span>

                        <ul class="navbar-nav">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="now-ui-icons ui-1_settings-gear-63" style="color:#141E30"></i>
                                    <p>
                                        <span class="d-lg-none d-md-block">Some Actions</span>
                                    </p>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="http://www.dlsu.edu.ph" style="color:#141E30">Website</a>
                                    <a class="dropdown-item" href="loginPage.php" style="color:#141E30">Logout</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- End Navbar -->
            <br><br><br><br><br>
            <div class="content">

                <div class="row" style="margin-left: 350px">
                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators" data-slide-to="0"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1" class="active"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item">
                                <img class="d-block" src="../sys/images/icons/slide1.jpg" alt="First slide" style="width: 497px; height: 373px;">
                                <div class="carousel-caption d-none d-md-block">
                                    <h5>Glorietta Courtyard, Makati</h5>
                                </div>
                            </div>
                            <div class="carousel-item active">
                                <img class="d-block" src="../sys/images/icons/slide2.jpg" alt="Second slide" style="width: 497px; height: 373px;">
                                <div class="carousel-caption d-none d-md-block">
                                    <h5>Greenbelt Park, Makati</h5>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img class="d-block" src="../sys/images/icons/slide3.jpg" alt="Third slide" style="width: 497px; height: 373px;">
                                <div class="carousel-caption d-none d-md-block">
                                    <h5>Bonifacio High Street, Taguig</h5>
                                </div>
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                            <i class="now-ui-icons arrows-1_minimal-left"></i>
                          </a>
                        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                            <i class="now-ui-icons arrows-1_minimal-right"></i>
                          </a>
                    </div>
                </div>

                <br><br>

                <div class="row" style="margin-left:120px">
                    <div class="card text-center" style="width: 20rem;">
                        <div class="card-body">
                            <img src="../sys/images/icons/image-icon3.png">
                            <h5 class="card-title">Choose Quality</h5>
                            <p class="card-text">We can assure you best quality, service and prices from our side.</p>
                        </div>
                    </div>

                    <div class="card text-center" style="width: 20rem;">
                        <div class="card-body">
                            <img src="../sys/images/icons/image-icon2.png">
                            <h5 class="card-title">Choose Durability</h5>
                            <p class="card-text">Assuring you of our best possible services at all times.</p>
                        </div>
                    </div>

                    <div class="card text-center" style="width: 20rem;">
                        <div class="card-body">
                            <img src="../sys/images/icons/image-icon1.png">
                            <h5 class="card-title">Choose Pancipane</h5>
                            <p class="card-text">Quality Service Delivered Customer Satisfaction Guaranteed</p>
                        </div>
                    </div>
                </div>

                <div class="row" style="margin-left:120px; width: 970px;">
                    <div class="card card-nav-tabs card-plain text-center">
                        <div class="card-header card-header-primary">
                            <div class="nav-tabs-navigation">
                                <div class="nav-tabs-wrapper">
                                    <ul class="nav nav-tabs" data-tabs="tabs">
                                        <li class="nav-item">
                                            <a class="nav-link active" href="#about" data-toggle="tab">About Company</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#contact" data-toggle="tab">Contact Information</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#products" data-toggle="tab">Our Products</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="tab-content text-center">
                                <div class="tab-pane active" id="about">
                                    <p><b>Company Profile</b><br> Our company, PANCIPANE TRADING, was established and started operations, as a single proprietorship, in 1980, engaged in business as a fabricator and lessor of high quality canvas, canopies and tents, because of their high quality, immediately gained wide acceptance from the public. Due to our desire to satisfy the ever-growing number of customers, our company developed bigger and sturdy tents, known as demountable utility tents, which are suited to the local weather conditions. The demountable tents have become so popular and in demand that other companies tried to imitate them. To protect its proprietary rights to the demountable utility tents, our company has registered with the Philippine Patent Office its invention, giving it the exclusive right to fabricate, market and lease the same to the public. The tent business has expanded beyond expectations and to meet its growing requirements, our company, which started as single proprietorship, was in the year 2001 organized and registered as a corporation with the Securities and Exchange Commission and is now known as PANCIPANE TRADING CORPORATION. From 3 workers in 1980, our company now employs 60 regular skilled and trained workers and continues to expand. Our company has become one of the leading companies in the tent industry.

                                        <br><br>
                                        <b>Mission / Vision</b><br> Pancipane Trading Corporation is proud in meeting the challenge to be the leading tent rental company throughout the country, being the first in the industry, gaining customer satisfaction and loyalty in all branches while creating opportunities for development of all employees and their families.
                                    </p>
                                </div>
                                <div class="tab-pane" id="contact">
                                    <p> <b>PANCIPANE TRADING CORPORATION</b> <br> 7816 S. Javier St. Pio del Pilar Makati <br><br> Email: info@pancipane.com<br> Phone: 8443655<br> Phone: 6247487<br> Cellphone: (Globe) 09175861630 <br> Facebook: @ptctents</p>
                                </div>
                                <div class="tab-pane" id="products">
                                    <p> Visit our facebook page for more information.</p>
                                    <a href="https://www.facebook.com/ptctents/" class="btn btn-primary">Facebook Page</a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
            <footer class="footer">
                <div class="container-fluid ">
                    <div class="copyright ">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())

                        </script>, Created by
                        <a href="" target="_blank " style="color:#01703D ">Bueza, Cu, Edwards, Go</a>.
                        
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js" type="text/javascript"></script>
<script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>

<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="../assets/js/plugins/bootstrap-switch.js"></script>

<!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
<script src="../assets/js/plugins/nouislider.min.js" type="text/javascript"></script>

<!--  Plugin for the DatePicker, full documentation here: https://github.com/uxsolutions/bootstrap-datepicker -->
<script src="../assets/js/plugins/bootstrap-datepicker.js" type="text/javascript"></script>

<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-kit.js?v=1.2.0" type="text/javascript"></script>


</html>
