<?php 
session_start();
session_destroy();
header("Location: "."../../pancipane/sys/loginPage.php"); //main page
?>
