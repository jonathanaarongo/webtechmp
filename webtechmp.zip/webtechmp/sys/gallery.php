<!doctype html>
<html lang="en">
<?php
session_start();
require_once("../sys/connect.php");
$msg = "";

  if (isset($_POST['upload'])) {
  	$image = $_FILES['image']['name'];
  	$target = "../gallery/".basename($image);
    $contents = file_get_contents($_FILES['image']['tmp_name']);
    $contents = base64_encode($contents);
  	$sql = "INSERT INTO gallery (image) VALUES ('{$contents}')";
  	mysqli_query($con, $sql);
  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
		$_POST = array();
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  $result = mysqli_query($con, "SELECT * FROM gallery");
  $_POST = array();

$flag=0;
$message = NULL;

$_SESSION['date'] = date("Y-m-d");
// $_SESSION['itemID']=FALSE;

 if(!isset($_POST['date']))
    $date = $_SESSION['date'];
 else
    $date = $_POST['date'];


  if($date == date("Y-m-d"))
{
    $message="<div id='clockbox'></div>";
    $flag = 2;
}

?>


<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/logo.PNG">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Gallery</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="gray" data-image="assets/img/books2.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a class="simple-text">
                    PHOTO GALLERY
                </a>

            </div>

            <ul class="nav">

                <li>
                        <a href="clientDashboard.php">
                            <i class="now-ui-icons education_atom"></i>
                            <p>Home</p>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>Profile</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="gallery.php">
                            <i style="color:black" class="now-ui-icons design_image"></i>
                            <p style="color:black">Photo Gallery</p>
                        </a>
                    </li>
            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed" style="background-color: #FFFFFF;">
            <div class="container-fluid">

                <div class="collapse navbar-collapse">

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="">
                               <font face="Roboto" color="black"><p>Account</p></font>
                            </a>
                        </li>

                        <li>
                            <a href="../logout.php">
                                <font face="Roboto" color="black"><p>Log out</p></font>
                            </a>
                        </li>
				            <li class="separator hidden-lg">
				        </li>
                    </ul>


                </div>
            </div>
        </nav>

       <br><br>
       <div class="content">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                        <h4 class="title"><b>GALLERY</b></h4>
                            <div class="row">
                                <div class="col">
                                <?php

                                if($result){
                                  while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) {
                                      echo "<img src='data:image;base64,". $row['image']. "' width='100' height='100'>";

                                }}
                                ?>
                                </div>
                              </div>

                              <form method="POST" action="" enctype="multipart/form-data">
                                  <input type="hidden" name="size" value="1000000">
                                  <font color="black">Select Image to Upload: </font>
                                  <div>
                                  <input type="file" name="image">
                                  </div>

                              <br>
                              <button type="submit" name="upload" class="btn btn-primary btn-fill">Add to Gallery</button>
                              </form>

                              <br>




                          <br>
                        </div>
                    </div>

                </div>
            </div>


        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>
                        <li>
                            <a href="#">
                                ABOUT
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                CONTACT
                            </a>
                        </li>

                    </ul>
                </nav>
                <p class="copyright pull-right">
										  &copy; <script>document.write(new Date().getFullYear())</script> <a>Go, Indefenzo</a>
                </p>
            </div>
        </footer>

    </div>
</div>


</body>
<!--     Fonts and icons     -->
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
<link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
<!-- CSS Files -->
<link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
<link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js" type="text/javascript"></script>
<script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>

<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="../assets/js/plugins/bootstrap-switch.js"></script>

<!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
<script src="../assets/js/plugins/nouislider.min.js" type="text/javascript"></script>

<!--  Plugin for the DatePicker, full documentation here: https://github.com/uxsolutions/bootstrap-datepicker -->
<script src="../assets/js/plugins/bootstrap-datepicker.js" type="text/javascript"></script>

<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-kit.js?v=1.2.0" type="text/javascript"></script>
</html>
