<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="icon" sizes="76x76" href="../assets/img/logo.png">
    <link rel="icon" type="image/png" href="images/icons/pancipane.jpg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Pancipane System</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
</head>

<body class="">
    <div class="wrapper ">
        <div class="sidebar" data-color="black">
            <div class="logo">
                <a href="" class="simple-text logo-normal">
                    <img src="images/icons/pancipane.jpg" />
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">

                    <li>
                        <a href="adminDashboard.php">
                            <i class="now-ui-icons education_atom"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li>
                        <a href="adminProfile.php">
                            <i class="now-ui-icons users_single-02"></i>
                            <p>Profile</p>
                        </a>
                    </li>
                    <li>
                        <a href="viewAccounts.php">
                            <i class="now-ui-icons business_badge"></i>
                            <p>View Accounts</p>
                        </a>
                    </li>
                    <li>
                        <a href="verifyAccounts.php">
                            <i class="now-ui-icons business_badge"></i>
                            <p>Verify Accounts</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="adminSalesReport.php">
                            <i style="color:black" class="now-ui-icons business_badge"></i>
                            <p style="color:black">Sales Report</p>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <i class="now-ui-icons business_badge"></i>
                            <p>Inventory Report</p>
                        </a>
                    </li>

                </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute bg-primary fixed-top">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="navbar-brand" href="">
                            <font color="#141E30">Hello, Admin!</font>
                        </a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <form>
                            <div class="input-group no-border">
                                <input type="text" value="" class="form-control" placeholder="Search...">
                                <span class="input-group-addon">
                                    <i class="now-ui-icons ui-1_zoom-bold" style="color:#141E30"></i>
                                </span>
                            </div>
                        </form>
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="now-ui-icons ui-1_settings-gear-63" style="color:#141E30"></i>
                                    <p>
                                        <span class="d-lg-none d-md-block">Some Actions</span>
                                    </p>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="http://www.dlsu.edu.ph" style="color:#141E30">Website</a>
                                    <a class="dropdown-item" href="loginPage.php" style="color:#141E30">Logout</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
						
				<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

				<!-- !PAGE CONTENT! -->
				<div class="w3-main" style="margin-left:50px;margin-top:50px;">

				  <!-- Header -->
				  <header class="w3-container" style="padding-top:22px">
					<h5><b><i class="fa fa-dashboard"></i> Sales Reports </b></h5>
				  </header>
				  <div class="w3-row-padding w3-margin-bottom">
					<div class="w3-quarter">
					  <div class="w3-container w3-red w3-padding-16">
						<div class="w3-left"><i class="fa fa-clock-o w3-xxxlarge"></i></div>
						<div class="w3-clear"></div>
						<a href="selectreport.php"><h5>Specific Date Reports</h5></a>
					  </div>
					</div>
					<div class="w3-quarter">
					  <div class="w3-container w3-blue w3-padding-16">
						<div class="w3-left"><i class="fa fa-percent w3-xxxlarge"></i></div>
						<div class="w3-clear"></div>
						<a href="dailyreport.php"><h5> Daily Sales Report</h5></a>
					  </div>
					</div>
					<div class="w3-quarter">
					  <div class="w3-container w3-teal w3-padding-16">
						<div class="w3-left"><i class="fa fa-calendar w3-xxxlarge"></i></div>
						<div class="w3-clear"></div>
						<a href="monthlyreport.php"><h5> Monthly Sales Report</h5></a>      </div>
					</div>
				  </div>

				  <!-- End page content -->
				</div>

</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js "></script>
<script src="../assets/js/core/popper.min.js "></script>
<script src="../assets/js/core/bootstrap.min.js "></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js "></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE "></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js "></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js "></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1 "></script>


</html>