<?php session_start();?>

<!--LOGIN VALIDATION-->
<?php 
    if(isset($_SESSION["u_username"]) && isset($_SESSION["home"])) {
        header('Location: '.$_SESSION["home"]);
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login | DLSU Bids to Pick</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="images/icons/pancipane.jpg" />
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">

    <body>

        <div class="limiter">
            <div class="container-login100">
                <div class="wrap-login100 p-t-30 p-b-20">
                    <form class="login100-form validate-form" action="../sys/verifylogin.php" method="post">
                        
                        <span class="login100-form-title p-b-40">
				        <font face="Montserrat"><strong>DLSU Bids to Pick</strong></font>
					</span>

                        <?php 
                        if(isset($_SESSION["errorlogin"])){
                            echo "<font face='Montserrat' size='2' color='red'>".$_SESSION["errorlogin"]."</font>";
                        }
                    ?>
                        <div class="wrap-input100 validate-input m-t-25 m-b-35" data-validate="Enter username">
                            <font face="Montserrat">Username</font>
                            <input class="input100" type="text" name="username" style="font-family:Montserrat;">
                            <span class="focus-input100"></span>
                        </div>
                        <div class="wrap-input100 validate-input m-b-50" data-validate="Enter password">
                            <font face="Montserrat">Password</font>
                            <input class="input100" type="password" name="password">
                            <span class="focus-input100"></span>
                        </div>

                        <input id="submitme" class="login100-form-btn" type="submit" style="background-color:#2D3255; font-family:Montserrat; cursor:pointer; font-weight:bold" value="LOGIN" />
                        <ul class="login-more p-t-40">
                            <li class="m-b-8">
                                <a href="CreateAccount.php" class="txt2" style="color:#01703D">
                                    <font face="Montserrat">Create Account</font>
                                </a>
                            </li>
                        </ul>
                    </form>
                </div>
            </div>
        </div>

        <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
        <script src="vendor/animsition/js/animsition.min.js"></script>
        <script src="vendor/bootstrap/js/popper.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="vendor/select2/select2.min.js"></script>
        <script src="vendor/daterangepicker/moment.min.js"></script>
        <script src="vendor/daterangepicker/daterangepicker.js"></script>
        <script src="vendor/countdowntime/countdowntime.js"></script>
        <script src="js/main.js"></script>

    </body>

</html>

<!--Properties Refresh-->
<?php $_SESSION["errorlogin"]="";?>
