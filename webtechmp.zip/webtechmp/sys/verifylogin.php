<?php session_start();?>
<?php

    if(isset ($_POST["username"]) && isset ($_POST["password"])){
    $_SESSION["userID"] = 'userID';


         //Properties
         $username = $_POST["username"];
         $password = $_POST["password"];
        
        
         //Queries  
         require_once("../sys/connect.php");
        
         //STRING INTERPOLATION
         $sqldata1 = "SELECT userID FROM users WHERE username ='$username'";
         $sqldata = "SELECT userID FROM users WHERE username='$username' and password = '$password';"; //client


         //query for client user
         $query1 = mysqli_query($con,$sqldata1);
         $query = mysqli_query($con,$sqldata);
         


        
         if (mysqli_num_rows($query)==1){
                $row = mysqli_fetch_array($query);
                $userID = $row['userID'];
             header('Location: '. "../sys/clientDashboard.php"); //go to client's dashboard
                $_SESSION["username"]=$username;
                $_SESSION["userID"]=$userID;
                $_SESSION['home'] = "../sys/clientDashboard.php";
         }
       
        
        else{
            header('Location: '."../sys/loginPage.php"); //go back to login
            $_SESSION["errorlogin"]="Login failed. Please try again.";
         }
    }
?>
