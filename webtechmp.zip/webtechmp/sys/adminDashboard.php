<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="icon" sizes="76x76" href="../assets/img/logo.png">
    <link rel="icon" type="image/png" href="images/icons/pancipane.jpg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Pancipane System</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />

    <!-- Calendar Dependencies-->

    <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
    <link href="../assets/event_calendar_js/dist/equinox.css" rel="stylesheet" type="text/css">

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>

    <script src="../assets/event_calendar_js/dist/equinox.min.js"></script>
    <!-- -->
</head>

<body class="">
    <div class="wrapper ">
        <div class="sidebar" data-color="black">
            <div class="logo">
                <a href="" class="simple-text logo-normal">
                    <img src="images/icons/pancipane.jpg" />
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">

                      <li class="active">
                        <a href="adminDashboard.php">
                            <i style="color:black" class="now-ui-icons education_atom"></i>
                            <p style="color:black">Calendar</p>
                        </a>
                    </li>
                    <li>
                        <a href="viewAccounts.php">
                            <i class="now-ui-icons business_badge"></i>
                            <p>View Accounts</p>
                        </a>
                    </li>
                    <li>
                        <a href="generateInventoryReport.php">
                            <i class="now-ui-icons business_badge"></i>
                            <p>Generate Inventory Report</p>
                        </a>
                    </li>
                     <li>
                        <a href="generateSalesReport.php">
                            <i class="now-ui-icons business_badge"></i>
                            <p>Generate Sales Report</p>
                        </a>
                    </li>
                    <li>
                        <a href="generateRentCharts.php">
                            <i class="now-ui-icons business_chart-pie-36"></i>
                            <p>Generate Rent Charts</p>
                        </a>
                    </li>
                    <li>
                        <a href="employeeCreateAccount.php">
                            <i class="now-ui-icons business_badge"></i>
                            <p>Create Employee Account</p>
                        </a>
                    </li>
                    <li>
                        <a href="verifyAccounts.php">
                            <i class="now-ui-icons business_badge"></i>
                            <p>Verify Accounts</p>
                        </a>
                    </li>
                     <li>
                        <a href="viewPaidAccounts.php">
                            <i class="now-ui-icons business_badge"></i>
                            <p>View Payment Status</p>
                        </a>
                    </li>
                    
                </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute bg-primary fixed-top">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="navbar-brand" href="">
                            <font color="#141E30">Dashboard</font>
                        </a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <span class="badge badge-primary" style="background-color: black">Welcome, Admin!</span>

                        <ul class="navbar-nav">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="now-ui-icons ui-1_settings-gear-63" style="color:#141E30"></i>
                                    <p>
                                        <span class="d-lg-none d-md-block">Some Actions</span>
                                    </p>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="http://www.dlsu.edu.ph" style="color:#141E30">Website</a>
                                    <a class="dropdown-item" href="loginPage.php" style="color:#141E30">Logout</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- End Navbar -->
            <br><br><br><br><br>
            <div class="content">

                <div class="card">
                    <div class="card-body text-center">
                        <div td style='text-align:left'>
                        <span class="badge badge-dark">Booking</span><br>
                        <span class="badge badge-success">Installation</span><br>
                        <span class="badge badge-primary">Pullout</span>
                        </div>
                        <iframe scrolling="no" frameborder="no" clocktype="html5" style="overflow:hidden;border:0;margin:0;padding:0;width:570px;height:75px;pointer-events: none;
                         cursor: default;" src="https://www.clocklink.com/html5embed.php?clock=036&timezone=GMT0800&color=black&size=570&Title=&Message=&Target=&From=2018,1,1,0,0,0&Color=black"></iframe>

                        <h5 class="title">
                            <?php
                                $dt = new DateTime();
                                echo $dt->format('F d, Y');
                                ?>
                        </h5>
                    </div>
                    <div class="event-calendar"></div>
                    <script>
                        $(function(){
                            $('.event-calendar').equinox();
                        });
                        var myEvents = [
                            <?php
                            require_once("../sys/connect.php");

                            $data1 ="SELECT * from ORDERS";
                            $query1 = mysqli_query($con,$data1);
                            if(mysqli_num_rows($query1)>0){
                            while($row = mysqli_fetch_array($query1)){
                            $book_d = strtotime($row["bookingDate"]);
                            $inst_d = strtotime($row["installationDate"]);
                            $pull_d = strtotime($row["pulloutDate"]);
                            ?>
                            {
                                start: '<?php echo $row["bookingDate"]?>',
                                end: '<?php echo $row["bookingDate"]?>',
                                title: 'Booked ORD<?php echo $row["ordersID"]?>',
                                url: '/pancipane/sys/viewSched.php?date=<?php echo date('Y-m-d',$book_d)?>',
                                class: '',
                                color: '#000',
                                data: { // data here }
                                }
                            },{
                                start: '<?php echo $row["installationDate"]?>',
                                end: '<?php echo $row["installationDate"]?>',
                                title: 'Install ORD<?php echo $row["ordersID"]?>',
                                url: '/pancipane/sys/viewSched.php?date=<?php echo date('Y-m-d',$inst_d)?>',
                                class: '',
                                color: '#6fe54c',
                                data: { // data here }
                                }
                            },{
                                start: '<?php echo $row["pulloutDate"]?>',
                                end: '<?php echo $row["pulloutDate"]?>',
                                title: 'Pullout ORD<?php echo $row["ordersID"]?>',
                                url: '/pancipane/sys/viewSched.php?date=<?php echo date('Y-m-d',$pull_d)?>',
                                class: '',
                                color: '#011fe5',
                                data: { // data here }
                                }
                            },
                            <?php
                            }
                            }
                            ?>
                        ];
                        $('.event-calendar').equinox({
                            events: myEvents
                        });
                    </script>
                </div>
                <footer class="footer ">
                    <div class="container-fluid ">
                        <div class="copyright ">
                            &copy;
                            <script>
                                document.write(new Date().getFullYear())

                            </script>, Created by
                            <a href="" target="_blank " style="color:#01703D ">Bueza, Cu, Edwards, Go</a>.
                        </div>
                    </div>
                </footer>
            </div>
        </div>
</body>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js "></script>
<script src="../assets/js/core/popper.min.js "></script>
<script src="../assets/js/core/bootstrap.min.js "></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js "></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE "></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js "></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js "></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1 "></script>


</html>
