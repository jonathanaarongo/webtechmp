<?php session_start();?>

<?php
    require_once("../sys/connect.php");

    //Properties
    if(isset($_GET["id"])){
            $id = $_GET["id"];
            //$sqldata ="";  
            $sqldata = "update client set accountStatus='REJECTED' where clientID='$id';";

            if(isset($sqldata)){
                $query = mysqli_query($con,$sqldata) or die(mysqli_error($con));
                header('Location: '.'../sys/verifyAccounts.php');
            }
        
    }
    else {
       header('Location: '.'../sys/verifyAccounts.php');
    }
?>