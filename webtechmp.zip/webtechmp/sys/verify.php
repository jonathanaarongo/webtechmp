<?php session_start();?>
<?php
require_once("../sys/connect.php");
if (isset($_GET['vkey'])){
    //PROCESS VERIFICATION
    $vkey = $_GET['vkey'];
    
    $data1="SELECT verificationStatus, vkey from client where verificationStatus is null and vkey='$vkey' LIMIT 1";
    $query1 = mysqli_query($con,$data1);
    
       if(mysqli_num_rows($query1)==1){
           $update="UPDATE client SET verificationStatus=1,accountStatus='APPROVED' where vkey='$vkey' LIMIT 1";

           if(isset($update)){
                $query = mysqli_query($con,$update);
                echo "Your account has been verified. You may now <a href='loginPage.php'>login</a>.";
            }
       }
        else {
            die("This account has already been verified. You may now <a href='loginPage.php'>login</a>.");
        }
}
?>

<html>
</html>