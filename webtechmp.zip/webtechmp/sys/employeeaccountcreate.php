<?php session_start();?>

<?php
    require_once("../sys/connect.php");

    //Properties
    $firstName =  ($_POST['firstName']);
    $lastName =  ($_POST['lastName']);
    $contactNumber = $_POST['contactNumber'];
    $employeeTypeID = $_POST['employeeTypeID'];
    $username =  ($_POST['username']);
    $password = ($_POST["password"]);
    $confirmpassword = ($_POST["confirmpassword"]);
    $email =  ($_POST['email']);
    
    //Queries
    $sqldata = "";

if ($_POST["password"] === $_POST["confirmpassword"]) {

        $sqldata = "INSERT INTO employee (lastName, firstName, contactNumber, email, employeeTypeID, username, password) 
        VALUES ('$lastName','$firstName','$contactNumber','$email','$employeeTypeID','$username', PASSWORD('$password'))";
}else{
    echo ("<script LANGUAGE='JavaScript'>
    window.alert('Password do not match! Please try again.');
    window.location.href='../sys/employeeCreateAccount.php';
    </script>");
    exit;
}
    if(isset($sqldata)){
        $query = mysqli_query($con,$sqldata) or die(mysqli_error($con));
        echo $query;
        
        echo ("<script LANGUAGE='JavaScript'>
    window.alert('The account has been successfully created.');
    window.location.href='../sys/employeeCreateAccount.php';
    </script>");
        exit;
    }

    header("Location: "."../sys/employeeCreateAccount.php");
?>
