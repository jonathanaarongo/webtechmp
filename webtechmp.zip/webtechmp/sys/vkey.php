<?php 
$vkey = md5(time().$u);
        
    echo $vkey;

?>