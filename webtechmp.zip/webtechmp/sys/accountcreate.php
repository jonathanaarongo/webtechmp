<?php session_start();?>

<?php
    require_once("../sys/connect.php");

    //Properties
    $firstName =  ($_POST['firstName']);
    $lastName =  ($_POST['lastName']);
    $idNumber =  ($_POST['idNumber']);
    $username =  ($_POST['username']);
    $confirmpassword = ($_POST["confirmpassword"]);
    $password = $_POST["password"];
    $email =  ($_POST['email']);
    //$vkey = md5(time().$username);
        
    //echo $vkey;
    
    //Queries
    $sqldata = "";

if ($_POST["password"] === $_POST["confirmpassword"]) {
   $sqldata = "INSERT INTO users ( lastName, firstName, idNumber, email, username, password) 
        VALUES ('$lastName','$firstName','$idNumber','$email','$username','$password')";
}
else {
    echo ("<script LANGUAGE='JavaScript'>
    window.alert('Password do not match! Please try again.');
    window.location.href='../sys/CreateAccount.php';
    </script>");
    exit;
}

        
   
    if(isset($sqldata)){
        
        $query = mysqli_query($con,$sqldata) or die(mysqli_error($con));
        echo $query;
        
        //SEND EMAIL
        $to = $email;
        $subject = "EMAIL VERIFICATION";
        $message = "Hi! Please click the link below to continue your registration process with the DLSU Bids to Pick.  http://localhost/pancipane/sys/verify.php?vkey=$vkey";
        $headers = "From: DLSU Bids to Pick\r\n";
        
        mail($to,$subject,$message,$headers); 
        
        /*echo ("<script LANGUAGE='JavaScript'>
    window.alert('Your account has been successfully created and awaiting approval. Please get back on us within two business days for an update to your account request.');
    window.location.href='../sys/clientCreateAccount.php';
    </script>");*/
        echo ("<script LANGUAGE='JavaScript'>
    window.alert('Your account has been successfully created. Please check your email for verification.');
    window.location.href='../sys/CreateAccount.php';
    </script>");
        //exit;
        
    }

    header("Location: "."../sys/CreateAccount.php");
?>
