<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="icon" sizes="76x76" href="../assets/img/logo.png">
    <link rel="icon" type="image/png" href="images/icons/pancipane.jpg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Pancipane System</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
</head>

<body class="">
    <div class="wrapper ">
        <div class="sidebar" data-color="black">
            <div class="logo">
                <a href="" class="simple-text logo-normal">
                    <img src="images/icons/pancipane.jpg" />
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="active">
                        <a href="clerkDashboard.php">
                            <i style="color:black" class="now-ui-icons education_atom"></i>
                            <p style="color:black">Notification</p>
                        </a>
                    </li>

                    <li>
                        <a href="placeOrderClerk.php">
                            <i class="now-ui-icons shopping_basket"></i>
                            <p>Place Order</p>
                        </a>
                    </li>
                    <li>
                        <a href="approveOrder.php">
                            <i class="now-ui-icons shopping_cart-simple"></i>
                            <p>Approve Order</p>
                        </a>
                    </li>
                    <li>
                        <a href="assignTruck1.php">
                            <i class="now-ui-icons shopping_delivery-fast"></i>
                            <p>Assign Trucks</p>
                        </a>
                    </li>
                    <li>
                        <a href="viewTruckSchedule.php">
                            <i class="now-ui-icons ui-1_calendar-60"></i>
                            <p>View Truck Schedule</p>
                        </a>
                    </li>
                    <li>
                        <a href="approvepay.php">
                            <i class="now-ui-icons ui-1_calendar-60"></i>
                            <p>Approve Pay</p>
                        </a>
                    </li>
                    <li>
                        <a href="viewInventoryClerk.php">
                            <i class="now-ui-icons shopping_box"></i>
                            <p>View Inventory</p>
                        </a>
                    </li>
                    <li>
                        <a href="orderFromOutsource.php">
                            <i class="now-ui-icons shopping_box"></i>
                            <p>Order from Outsource</p>
                        </a>
                    </li>
                                        <li>
                        <a href="returnToOutsource.php">
                            <i class="now-ui-icons shopping_box"></i>
                            <p>Return to outsource</p>
                        </a>
                    </li>
                    
                </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute bg-primary fixed-top">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="navbar-brand" href="">
                            <font color="#141E30">Notification</font>
                        </a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <span class="badge badge-primary" style="background-color: black">Welcome, Clerk!</span>

                        <ul class="navbar-nav">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="now-ui-icons ui-1_settings-gear-63" style="color:#141E30"></i>
                                    <p>
                                        <span class="d-lg-none d-md-block">Some Actions</span>
                                    </p>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="http://www.dlsu.edu.ph" style="color:#141E30">Website</a>
                                    <a class="dropdown-item" href="loginPage.php" style="color:#141E30">Logout</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- End Navbar -->
            <br><br><br><br><br>
            <div class="content">

                <div class="card">
                    <div class="card-body text-center">
                        <iframe scrolling="no" frameborder="no" clocktype="html5" style="overflow:hidden;border:0;margin:0;padding:0;width:570px;height:75px;pointer-events: none;
                         cursor: default;" src="https://www.clocklink.com/html5embed.php?clock=036&timezone=GMT0800&color=black&size=570&Title=&Message=&Target=&From=2018,1,1,0,0,0&Color=black"></iframe>

                        <h5 class="title">
                            <?php
                                $dt = new DateTime();
                                echo $dt->format('F d, Y');
                                ?>
                        </h5>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="title">Notifications</h5>
                        <footer class="blockquote-footer">Orders for installation that need to be assigned to a truck</footer>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Company</th>
                                    <th>Item</th>
                                    <th>Quantity</th>
                                    <th>Installation Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                       require_once("../sys/connect.php");
                       
                       $data1 ="SELECT orders.ordersID, orders.clientID, orders.statusOrder, orders.addOrderQty, orders.addOrderItem, orders.installationDate,
client.clientID, client.companyName FROM orders JOIN client ON orders.clientID = client.clientID WHERE 
DATE_FORMAT(orders.installationDate, '%Y-%m-%d')=CURDATE() and orders.qtyLeft != 0;";
                       $query1 = mysqli_query($con,$data1);
                       if(mysqli_num_rows($query1)>0){
                           while($row = mysqli_fetch_array($query1)){
                               ?>
                                    <tr>
                                        <td>
                                            <?php echo $row["ordersID"];?>
                                        </td>
                                        <td>
                                            <?php echo $row["companyName"];?>
                                        </td>
                                        <td>
                                            <?php echo $row["addOrderItem"];?>
                                        </td>
                                        <td>
                                            <?php echo $row["addOrderQty"];?>
                                        </td>
                                        <td>
                                            <?php echo $row["installationDate"];?>
                                        </td>
                                    </tr>
                                    <!--echo
                       "<tr>".
                       "<td>".$row["inventoryID"]."</td>".
                       "<td>".$row["inventoryName"]."</td>".
                       "<td>".$row["inStockQty"]."</td>".
                       "<td><a href='orderFromOutsource.php' class='btn btn-primary'>ORDER</a></td>".
                       "</tr>";-->
                                    <?php }
                       }
                   ?>

                            </tbody>
                        </table>
                    </div>
                </div>
                
                        <div class="card">
                    <div class="card-header">
                        <h5 class="title">Notifications</h5>
                        <footer class="blockquote-footer">Orders for pullout that need to be assigned to a truck</footer>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Company</th>
                                    <th>Item</th>
                                    <th>Quantity</th>
                                    <th>Pullout Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                       require_once("../sys/connect.php");
                       
                       $data1 ="SELECT orders.ordersID, orders.clientID, orders.statusOrder, orders.addOrderQty, orders.addOrderItem, orders.pulloutDate,
client.clientID, client.companyName FROM orders JOIN client ON orders.clientID = client.clientID WHERE 
DATE_FORMAT(orders.pulloutDate, '%Y-%m-%d')=CURDATE() and orders.qtyLeft != 0;";
                       $query1 = mysqli_query($con,$data1);
                       if(mysqli_num_rows($query1)>0){
                           while($row = mysqli_fetch_array($query1)){
                               ?>
                                    <tr>
                                        <td>
                                            <?php echo $row["ordersID"];?>
                                        </td>
                                        <td>
                                            <?php echo $row["companyName"];?>
                                        </td>
                                        <td>
                                            <?php echo $row["addOrderItem"];?>
                                        </td>
                                        <td>
                                            <?php echo $row["addOrderQty"];?>
                                        </td>
                                        <td>
                                            <?php echo $row["pulloutDate"];?>
                                        </td>
                                    <!--echo
                       "<tr>".
                       "<td>".$row["inventoryID"]."</td>".
                       "<td>".$row["inventoryName"]."</td>".
                       "<td>".$row["inStockQty"]."</td>".
                       "<td><a href='orderFromOutsource.php' class='btn btn-primary'>ORDER</a></td>".
                       "</tr>";-->
                                    <?php }
                       }
                   ?>

                            </tbody>
                        </table>
                    </div>
                </div>

                <footer class="footer ">
                    <div class="container-fluid ">
                        <div class="copyright ">
                            &copy;
                            <script>
                                document.write(new Date().getFullYear())

                            </script>, Created by
                            <a href="" target="_blank " style="color:#01703D ">Bueza, Cu, Edwards, Go</a>.
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
</body>

<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js "></script>
<script src="../assets/js/core/popper.min.js "></script>
<script src="../assets/js/core/bootstrap.min.js "></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js "></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE "></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js "></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js "></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1 "></script>


</html>
