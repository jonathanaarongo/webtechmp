<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="icon" sizes="76x76" href="../assets/img/logo.png">
    <link rel="icon" type="image/png" href="images/icons/pancipane.jpg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Pancipane System</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-dashboard.css?v=1.0.1" rel="stylesheet" />
</head>

<body class="">
    <div class="wrapper ">
        <div class="sidebar" data-color="black">
            <div class="logo">
                <a href="" class="simple-text logo-normal">
                    <img src="images/icons/pancipane.jpg" />
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">

                    <li>
                        <a href="adminDashboard.php">
                            <i class="now-ui-icons education_atom"></i>
                            <p>Calendar</p>
                        </a>
                    </li>
                    <li>
                        <a href="viewAccounts.php">
                            <i class="now-ui-icons business_badge"></i>
                            <p>View Accounts</p>
                        </a>
                    </li>
                    <li>
                        <a href="generateInventoryReport.php">
                            <i class="now-ui-icons business_badge"></i>
                            <p>Generate Inventory Report</p>
                        </a>
                    </li>
                    <li>
                        <a href="generateSalesReport.php">
                            <i class="now-ui-icons business_badge"></i>
                            <p>Generate Sales Report</p>
                        </a>
                    </li>
                         <li>
                        <a href="generateRentCharts.php">
                            <i class="now-ui-icons business_chart-pie-36"></i>
                            <p>Generate Rent Charts</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="employeeCreateAccount.php">
                            <i style="color:black" class="now-ui-icons business_badge"></i>
                            <p style="color:black">Create Employee Account</p>
                        </a>
                    </li>
                    <li>
                        <a href="verifyAccounts.php">
                            <i class="now-ui-icons business_badge"></i>
                            <p>Verify Accounts</p>
                        </a>
                    </li>
                    <li>
                        <a href="viewPaidAccounts.php">
                            <i class="now-ui-icons business_badge"></i>
                            <p>View Payment Status</p>
                        </a>
                    </li>

                </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute bg-primary fixed-top">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="navbar-brand" href="">
                            <font color="#141E30">Create Employee Account</font>
                        </a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <form>
                            <div class="input-group no-border">
                                <input type="text" value="" class="form-control" placeholder="Search...">
                                <span class="input-group-addon">
                                    <i class="now-ui-icons ui-1_zoom-bold" style="color:#141E30"></i>
                                </span>
                            </div>
                        </form>
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="now-ui-icons ui-1_settings-gear-63" style="color:#141E30"></i>
                                    <p>
                                        <span class="d-lg-none d-md-block">Some Actions</span>
                                    </p>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="http://www.dlsu.edu.ph" style="color:#141E30">Website</a>
                                    <a class="dropdown-item" href="loginPage.php" style="color:#141E30">Logout</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- End Navbar -->
            <br><br><br><br><br>
            <div class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="title">Create Employee Account</h5>
                            </div>
                            <div class="card-body">

                                <form action="../sys/employeeaccountcreate.php" name="create" method="post" onsubmit="clicked();">
                                    <div class="row">
                                        <div class="col-md-6 pr-1">
                                            <div class="form-group">
                                                <label>First Name</label>
                                                <input type="text" name="firstName" class="form-control" placeholder="First Name" value="" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6 pl-1">
                                            <div class="form-group">
                                                <label>Last Name</label>
                                                <input type="text" name="lastName" class="form-control" placeholder="Last Name" value="" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 pr-1">
                                            <div class="form-group">
                                                <label>Contact Number</label>
                                                <input type="text" name="contactNumber" class="form-control" placeholder="Contact" value="" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6 pl-1">
                                            <div class="form-group">
                                                <label>E-mail</label>
                                                <input type="email" name="email" class="form-control" placeholder="E-mail Address" value="" required>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-md-4 pr-1">
                                            <div class="form-group">
                                                <label>Employee Type</label>
                                                <select class="form-control" name="employeeTypeID">
                                                  <option value="1">Inventory</option>
                                                  <option value="2">Clerk</option>
                                                  <option value="3">Admin</option>
                                                  <option value="4">Dispatcher</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-md-4 pr-1">
                                            <div class="form-group">
                                                <label>Username</label>
                                                <input type="text" name="username" class="form-control" placeholder="Username" value="" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 pr-1">
                                            <div class="form-group">
                                                <label>Password</label>
                                                <input type="password" name="password" class="form-control" placeholder="Password" value="" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 pr-1">
                                            <div class="form-group">
                                                <label>Confirm Password</label>
                                                <input type="password" name="confirmpassword" class="form-control" placeholder=" Confirm Password" value="" required>
                                            </div>
                                        </div>
                                    </div>
                                    <br>

                                    <input id="submitme" class="btn btn-primary" type="submit" style="float:right" value="CREATE ACCOUNT " />
                                </form>
                                <a href="loginPage.php" style="color:#FFF "><button type="button " class="btn btn-default " style="float:left ">CANCEL</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer ">
                <div class="container-fluid ">
                    <div class="copyright ">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())

                        </script>, Created by
                        <a href="" target="_blank " style="color:#01703D ">Bueza, Cu, Edwards, Go</a>.
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>

<script type="text/javascript">
    function clicked() {
        if (confirm('Are you sure you want to create this account?')) {
            create.submit();
        } else {
            return false;
        }
    }

</script>
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js "></script>
<script src="../assets/js/core/popper.min.js "></script>
<script src="../assets/js/core/bootstrap.min.js "></script>
<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js "></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE "></script>
<!-- Chart JS -->
<script src="../assets/js/plugins/chartjs.min.js "></script>
<!--  Notifications Plugin    -->
<script src="../assets/js/plugins/bootstrap-notify.js "></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/now-ui-dashboard.js?v=1.0.1 "></script>


</html>
